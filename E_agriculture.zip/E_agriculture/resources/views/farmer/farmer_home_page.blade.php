@extends('farmer.headerFooter')
@section('body')
    <div >
        <h1  style="color: limegreen ;margin-left: 550px">Welcome YOUR pAGE......</h1>
        <P style="color: black ;margin-left: 550px; font-size: 30px;font-style: italic; font-weight: bold ;line-height: 120px" >
            You can Import crops ....For bidding....$ found Customer details.....</P>
    </div>
    @endsection



