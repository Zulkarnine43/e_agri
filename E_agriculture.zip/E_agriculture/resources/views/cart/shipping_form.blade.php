@extends('home.headerFooter');
@section('body')

    <h3 class="col-md-offset-3 col-md-4 text-success">Shipping Info goes here.....</h3>
    <form action="{{route('shippingGoes')}}" method="POST" class="form-right">
        {{ csrf_field() }}

        <div class="content">
            <div class="login">
                <div class="main-agileits">
                    <div class="form-w3agile form1">
                        <div class="key">
                            <input class="col-md-offset-3 col-md-4 text-center"  type="text" class="input-lg float-lg-right" name="fullname" value="" placeholder="fullname" >
                            <input type="hidden" name="id" value="{{$product->id}}">
                            <input type="hidden" name="product_quantity" value="{{$qty}}">
                            <input type="hidden" name="total_price" value="{{$sum}}">
                        </div>

                        <div class="key">
                            <input class="col-md-offset-3 col-md-4 text-center"  type="text" class="input-lg" name="email" value=""  placeholder="email">

                        </div>

                        <div class="key">
                            <input class="col-md-offset-3 col-md-4 text-center"  type="text" class="input-lg" name="phone_number" placeholder=" phone_number">

                        </div>
                        <div class="key">
                            <input class="col-md-offset-3 col-md-4 text-center"  type="text" class="input-lg" name="address" placeholder="address">
                        </div>
                        <div class="key">
                            <select name="payment_type" class="col-md-offset-3 col-md-4 text-center">
                                <option>Select Paymeny type</option>
                                <option>Bkash</option>
                                <option>Paypal</option>
                                <option>Cash on Delivery</option>
                            </select>
                        </div>

                        <input class="col-md-offset-3 col-md-4 text-center text-gray-900"  type="submit" name="btn" value="Submit">
                    </div>

                </div>
            </div>
        </div>
    </form>
    </div>

@endsection