<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class gallary_add extends Model
{
    //
    protected $fillable=['product_name','crop_type','product_description','product_image'];
}
