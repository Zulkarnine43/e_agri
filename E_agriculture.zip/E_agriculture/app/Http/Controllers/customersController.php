<?php

namespace App\Http\Controllers;

use App\add_crop;
use App\crop_message;
use App\customer_registration;
use App\farmer_registration;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class customersController extends Controller
{
    //
    public function customer_register(){
        return view('customer.customer_register');
    }
        public function CustregisterSave(Request $request){

          $this->validate($request,[
              'fullname'=>'required',
              'username'=>'required',
              'email'=>'required',
              'mobile'=>'required',
              'district'=>'required',
              'postal_code'=>'required',
              'password'=>'required|Max:10|Min:5',
              'confirm_password'=>'required|Max:10|Min:5'
            ]);
            $regis = new customer_registration();
            $regis->fullname = $request->fullname;
            $regis->username = $request->username;
            $regis->email = $request->email;
            $regis->mobile = $request->mobile;
            $regis->district = $request->district;
            $regis->postal_code = $request->postal_code;
            $regis->password = $request->password;
            $regis->confirm_password = $request->confirm_password;
            $regis->save();
            return redirect('/customer/login');
          //customer_registration::created($request->all());

    }
    public function customer_login(){
        return view('customer.customer_login');
    }

    public function cust_login_check(Request $request){
        $customer = customer_registration::where('email',$request->email )->first();
        $customer2= customer_registration::where('password', $request->password)->first();
        if($customer && $customer2){
            Session::put('email',$customer);
            return redirect('/customer/page/home');
        }
        else {
            return redirect('/customer/login')->with('message', 'required valid password');
        }
    }

    public function customer_home_page(){
        return view('customer.customer_home_page');
    }
    public function farmer_info(){
        $farm_infos=farmer_registration::all();
        return view('customer.farmer_view',['farm_infos'=>$farm_infos]);
    }
public function Collection_Info(){
        $allCrops=add_crop::all();
        return view('customer.collection_info',['allCrops'=>$allCrops]);
}
    public function crop_details($id){
        $crop = add_crop::find($id);
        $cust=Session::get('email');
        $messages=crop_message::where('crop_id',$crop->id)->get();
        $farmer=farmer_registration::where('email',$crop->email)->first();
        return view('customer.collection_details',['crop'=>$crop,'farmer'=>$farmer,'cust'=>$cust,'messages'=>$messages]);
    }

public function sendMessage(Request $request){
    $regis = new crop_message();
    $regis->crop_id = $request->crop_id;
    $regis->product_name = $request->product_name;
    $regis->farmer_email = $request->farmer_email;
    $regis->cust_id = $request->cust_id;
    $regis->name = $request->name;
    $regis->email = $request->email;
    $regis->mobile = $request->mobile;
    $regis->message = $request->message;
    $regis->save();
    return redirect('/collection/info')->with('message','Send bidding message Successfully');
}
}
