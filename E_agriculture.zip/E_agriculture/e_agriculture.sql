-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 06, 2019 at 07:00 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e_agriculture`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_crops`
--

CREATE TABLE `add_crops` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `crop_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_description` varchar(5000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_date_bidding` date NOT NULL,
  `product_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `add_crops`
--

INSERT INTO `add_crops` (`id`, `email`, `product_name`, `crop_type`, `product_quantity`, `product_price`, `product_description`, `long_description`, `last_date_bidding`, `product_image`, `created_at`, `updated_at`) VALUES
(9, 'zns601@gmail.com', 'Lotkon', 'Fruits', '10 tree', '20000', 'কেজি প্রতি ৩৫ থেকে ৪০ টাকা করে নিতে পারে, সাথে ইচ্ছা করলে কাঁঠাল, পেয়ারা আনতে পারেন আর নরসিংদীর কলা টেস্ট করে দেখতে পারেন হতাশ হবেন নাহ নিশ্চিত।', '<p>লটকন মানেই নরসিংদী জেলার নাম সবার আগে আসবে কারন নরসিংদী জেলার রায়পুরা, শিবপুর, মরজাল এসব উপজেলায় সবচেয়ে বেশি লটকন হয়ে থাকে। লটকন আমাদের সবারই প্রিয় ফল কে না পছন্দ করে, যারা সারাদিনই কাজে ব্যাস্ত থাকেন তাদের জন্য ১ দিনের খুব আরামপ্রিয় একটা ভ্রমন। তবে লটকন বাগানের পাশাপাশি অনেক কিছু আপনার মন ভরে দিতে পারে বিশেষ করে মাটির তৈরি বাড়ি, চারিদিকের শান্ত পরিবেশ এগুলোতো আছে তার পাশাপাশি নানা ধরনের ফল তো আপনাকে অবশ্যই আকর্ষন করবে।</p>', '0000-00-00', 'product_images/lotkon.jpg', '2019-10-30 07:04:24', '2019-10-30 07:04:24'),
(10, 'zulkarnine43@gmail.com', 'mango garden', 'Fruits', '20 trees', '8000', 'কাঁচা অবস্থায় রং সবুজ এবং পাকা অবস্থায় হলুদ রং হয়ে থাকে।', '<p>আম গাছ সাধারণত ৩৫-৪০মি: (১১৫-১৩০ ফিট) লম্বা এবং সর্বোচ্চ ১০মি: (৩৩ ফিট) ব্যাসার্ধের হয়ে থাকে। আম গাছ বহু বছর বাঁচে, এর কিছু প্রজাতিকে ৩০০ বছর বয়সেও ফলবতী হতে দেখা যায়। এর প্রধান শিকড় মাটির নীচে প্রায় ৬মি: (২০ ফিট) গভীর পর্যন্ত যায়। আম গাছের পাতা চিরসবুজ, সরল, পর্যায়ক্রমিক, ১৫-৩৫ সে.মি. লম্বা এবং ৬-১৬ সে.মি. চওড়া হয়ে থাকে; কচি পাতা দেখতে লালচে-গোলাপী রং এর হয়। আমের মুকুল বের হয় ডালের ডগা থেকে, মুকুল থেকে শুরু করে আম পাকা পর্যন্ত প্রায় ৩-৬ মাস সময় লাগে।</p>', '0000-00-00', 'product_images/lichu.jpg', '2019-10-30 23:49:48', '2019-10-31 00:49:23'),
(12, 'zulkarnine43@gmail.com', 'Malta', 'Fruits', '10 tree', '10000', 'মাল্টা, আনুষ্ঠানিকভাবে হিসাবে প্রজাতন্ত্রী মাল্টা পরিচিত একটি প্রজাতান্ত্রিক রাষ্ট্র। এর রাজধানীর নাম ভাল্লেত্তা।', '<p>দেশটির মাথাপিছু আয় প্রায় ৪৫ হাজার ৬০৬ ডলার। এর অর্থনীতির মূল চালিকা শক্তি হলো বৈদেশিক বাণিজ্য। দেশটি পৃথিবীর অন্যান্য দেশের নৌবাণিজ্যের শিপমেন্ট পয়েন্ট হিসেবে কাজ করে। এছাড়া বৈদ্যুতিক সরঞ্জাম ও টেক্সটাইল শিল্প এবং পর্যটন শিল্প এর অর্থিনীতিতে গুরুত্বপূর্ণ ভূমিকা পালন করে।</p>', '0000-00-00', 'product_images/malta.jpg', '2019-11-01 04:35:20', '2019-11-01 04:35:20'),
(13, 'zulkarnine43@gmail.com', 'grapes', 'Fruits', '10 tree', '9000', 'Good for health', '<p>Made by Bangladesh</p>', '2019-11-20', 'product_images/grapes.jpg', '2019-11-03 08:59:15', '2019-11-03 08:59:15');

-- --------------------------------------------------------

--
-- Table structure for table `crop_messages`
--

CREATE TABLE `crop_messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `crop_id` varchar(1000) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `farmer_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cust_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `crop_messages`
--

INSERT INTO `crop_messages` (`id`, `crop_id`, `product_name`, `farmer_email`, `cust_id`, `name`, `email`, `mobile`, `message`, `created_at`, `updated_at`) VALUES
(18, '13', 'grapes', 'zulkarnine43@gmail.com', '5', 'Abul', 'abul@gmail.com', '01876784567', 'i will buy 9500 taka..', '2019-11-03 09:45:07', '2019-11-03 09:45:07'),
(19, '12', 'Malta', 'zulkarnine43@gmail.com', '5', 'Abul', 'abul@gmail.com', '01989419776', 'i will buy 10,000......', '2019-11-05 06:15:30', '2019-11-05 06:15:30');

-- --------------------------------------------------------

--
-- Table structure for table `customer_registrations`
--

CREATE TABLE `customer_registrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal_code` int(200) NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirm_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `customer_registrations`
--

INSERT INTO `customer_registrations` (`id`, `fullname`, `username`, `email`, `mobile`, `district`, `postal_code`, `password`, `confirm_password`, `created_at`, `updated_at`) VALUES
(5, 'Abul', 'abul1', 'abul@gmail.com', '01987643423', 'Rajshahi', 0, '12345678', '12345678', '2019-10-31 00:04:34', '2019-10-31 00:04:34'),
(7, 'Faruqe', 'faruqe22', 'admin@blogs.com', '01976348745', 'Rajshahi', 1570, '12345678', '12345678', '2019-11-02 03:26:34', '2019-11-02 03:26:34');

-- --------------------------------------------------------

--
-- Table structure for table `farmer_registrations`
--

CREATE TABLE `farmer_registrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postal_code` int(200) NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `confirm_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `farmer_registrations`
--

INSERT INTO `farmer_registrations` (`id`, `fullname`, `username`, `email`, `mobile`, `district`, `postal_code`, `password`, `confirm_password`, `created_at`, `updated_at`) VALUES
(30, 'zulkarnine', 'nine1', 'zulkarnine43@gmail.com', '01989419776', 'Dhaka', 1200, '12345678', '12345678', '2019-11-03 03:09:41', '2019-11-03 03:09:41'),
(31, 'alomgir', 'alom1', 'alomgir@gmail.com', '01987345678', 'Barishal', 1200, '12345678', '12345678', '2019-11-03 09:09:42', '2019-11-03 09:09:42');

-- --------------------------------------------------------

--
-- Table structure for table `gallary_adds`
--

CREATE TABLE `gallary_adds` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `crop_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gallary_adds`
--

INSERT INTO `gallary_adds` (`id`, `product_name`, `crop_type`, `product_description`, `product_image`, `created_at`, `updated_at`) VALUES
(1, 'paddy', 'Food', 'new year', 'gallary_images/g5.jpg', '2019-10-23 02:12:40', '2019-10-23 02:12:40'),
(2, 'abc', 'vegetables', 'Good for health', 'gallary_images/g7.jpg', '2019-10-23 04:46:56', '2019-10-23 04:46:56'),
(3, 'lichu', 'Fruits', 'Good for health', 'gallary_images/lichu.jpg', '2019-11-04 11:23:35', '2019-11-04 11:23:35'),
(4, 'Lotkon', 'Fruits', 'Good for health', 'gallary_images/lotkon2.jpg', '2019-11-04 11:24:00', '2019-11-04 11:24:00'),
(5, 'grapes', 'Fruits', 'Good for health', 'gallary_images/grapes.jpg', '2019-11-04 11:24:24', '2019-11-04 11:24:24'),
(6, 'mango garden', 'Fruits', 'Good for health', 'gallary_images/mango.jpg', '2019-11-04 11:24:50', '2019-11-04 11:24:50'),
(7, 'banana', 'Fruits', 'Good for health', 'gallary_images/banana.jpg', '2019-11-04 11:25:12', '2019-11-04 11:25:12'),
(8, 'narkel', 'Fruits', 'Good for health', 'gallary_images/narkel.jpg', '2019-11-04 11:25:26', '2019-11-04 11:25:26'),
(9, 'papaya', 'Fruits', 'Good for health', 'gallary_images/papaya.jpg', '2019-11-04 11:25:56', '2019-11-04 11:25:56');

-- --------------------------------------------------------

--
-- Table structure for table `home_adds`
--

CREATE TABLE `home_adds` (
  `id` int(10) UNSIGNED NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `crop_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `long_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `home_adds`
--

INSERT INTO `home_adds` (`id`, `product_name`, `crop_type`, `product_quantity`, `product_price`, `product_description`, `long_description`, `product_image`, `created_at`, `updated_at`) VALUES
(1, 'paddy', 'Food', '10', '50', 'new year', 'Made By Bangladesh.....', 'home_images/g5.jpg', '2019-10-23 00:53:40', '2019-10-23 00:53:40'),
(2, 'A', 'vegetables', '10', '300', 'new brands', 'made in Bangladesh', 'home_images/g4.jpg', '2019-10-23 09:17:31', '2019-10-23 09:17:31'),
(3, 'b', 'Fruits', '10', '2000', 'new year', 'good for health', 'home_images/a3.jpg', '2019-10-23 09:18:45', '2019-10-23 09:18:45'),
(4, 'c', 'vegetables', '10', '324', 'Good for health', 'Made By bangladesh', 'home_images/3.jpg', '2019-10-23 09:20:07', '2019-10-23 09:20:07');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_10_21_160639_create_farmer_registrations_table', 1),
(4, '2019_10_21_175939_create_customer_registrations_table', 2),
(5, '2019_10_21_195751_create_add_crops_table', 3),
(6, '2019_10_22_075040_create_add_crops_table', 4),
(7, '2019_10_22_151833_create_crop_messages_table', 5),
(8, '2019_10_23_064334_create_home_adds_table', 6),
(9, '2019_10_23_080618_create_gallary_adds_table', 7),
(10, '2019_11_06_175041_create_shipping_forms_table', 8);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shipping_forms`
--

CREATE TABLE `shipping_forms` (
  `id` int(10) UNSIGNED NOT NULL,
  `fullname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_quantity` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shipping_forms`
--

INSERT INTO `shipping_forms` (`id`, `fullname`, `email`, `phone_number`, `address`, `payment_type`, `product_name`, `product_price`, `product_quantity`, `total_price`, `created_at`, `updated_at`) VALUES
(1, 'zulkarnine', 'zns601@gmail.com', '01976524652', 'kolabagan,Dhaka', 'Paypal', 'A', '300', '4', '1200', '2019-11-06 11:58:08', '2019-11-06 11:58:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Zulkar Nine', 'zulkarnine43@gmail.com', '$2y$10$sHS85NMKKsxgiPK17W4oyeyfzeDifDYl7gulErCeYDluxRg8Fp0l2', 'ijMwSoojf6TarDN9YqqyERqn7Xo3mBi1YzY1vgjzC0r2YjJl8U35K7bfamar', '2019-10-24 00:50:02', '2019-10-24 00:50:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_crops`
--
ALTER TABLE `add_crops`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crop_messages`
--
ALTER TABLE `crop_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_registrations`
--
ALTER TABLE `customer_registrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `farmer_registrations`
--
ALTER TABLE `farmer_registrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallary_adds`
--
ALTER TABLE `gallary_adds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_adds`
--
ALTER TABLE `home_adds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `shipping_forms`
--
ALTER TABLE `shipping_forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_crops`
--
ALTER TABLE `add_crops`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `crop_messages`
--
ALTER TABLE `crop_messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `customer_registrations`
--
ALTER TABLE `customer_registrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `farmer_registrations`
--
ALTER TABLE `farmer_registrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `gallary_adds`
--
ALTER TABLE `gallary_adds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `home_adds`
--
ALTER TABLE `home_adds`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `shipping_forms`
--
ALTER TABLE `shipping_forms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
