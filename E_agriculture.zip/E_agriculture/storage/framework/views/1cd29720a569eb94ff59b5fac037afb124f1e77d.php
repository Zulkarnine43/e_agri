<?php $__env->startSection('body'); ?>

    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-body">
                    <h3 class="text-success text-success"></h3>
                    <h3 class="col-md-offset-3 col-md-5 text-center text-success" style="background-color: limegreen"> Register</h3>

                    <form action="<?php echo e(route('CustregisterSave')); ?>" method="POST" >
                        <?php echo csrf_field(); ?>
                        <div class="input-lg">
                            <input class="col-md-offset-3 col-md-5 text-center"   type="text" value="" name="fullname" placeholder="FullName" required>

                        </div>
                        <div class="input-lg">
                            <input class="col-md-offset-3 col-md-5 text-center"   type="text" value="" name="username" placeholder="Username" required>

                        </div>
                        <div class="input-lg">
                            <input class="col-md-offset-3 col-md-5 text-center"  type="text" value="" name="email"  placeholder="Email" required>

                        </div>
                        <div class="input-lg">
                            <input class="col-md-offset-3 col-md-5 text-center"   type="number" value="" name="mobile" placeholder="Mobile" required>

                        </div>
                        <div class="input-lg">
                            <select class="col-md-offset-3 col-md-5 text-center" name="district" required >
                                <option value="null"><-------Select----------------></option>
                                <option value="Dhaka">Dhaka</option>
                                <option value="Rajshahi">Rajshahi</option>
                                <option value="Khulna">Khulna</option>
                                <option value="Chittagong">Chittagong</option>
                                <option value="Barishal">Barishal</option>
                                <option value="Comilla">Comilla</option>
                                <option value="Rangpur">Rangpur</option>
                            </select>

                        </div>

                        <div class="input-lg">
                            <input class="col-md-offset-3 col-md-5 text-center"   type="number" value="" name="postal_code" placeholder="postal_code" min="1">
                            <span><?php echo e($errors->has('postal_code') ? $errors->first('postal_code') : ' '); ?></span>
                        </div>

                        <div class="input-lg">
                            <input class="col-md-offset-3 col-md-5 text-center"  type="password" value="" name="password"  placeholder="Password" required>

                        </div>
                        <div class="input-lg">
                            <input class="col-md-offset-3 col-md-5 text-center"  type="password" value="" name="confirm_password"  placeholder="ConfirmPassword" required>

                        </div>
                        <input class="col-md-offset-5 col-md-2 text-center text-black-50 btn-success" type="submit" name="btn" value="Submit" required>
                    </form>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>