<?php $__env->startSection('body'); ?>
    <style>
        .m {
            background-color: limegreen;
            text-align: center;
        }
        .t1{
            background-color: black;
            color: white;
            font-weight: bold;
            font-size: 10px;
            text-align: left;
        }
        .t2{
            color: black;
            font-weight: bold;
            font-size: 11px;
            text-align: left;
        }
    </style>
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="m">Manage Crops Info</h3>
                    <table class="table-bordered table-hover ">
                        <tr class="t1">
                            <th>Sl No</th>
                            <th>product_name </th>
                            <th>crop_type </th>
                            <th>product_quantity</th>
                            <th>product_price</th>
                            <th>product_description</th>
                            <th>long_description</th>
                            <th>product_image</th>
                            <th>Action</th>
                        </tr>
                        <?php ($i=1); ?>;
                        <?php $__currentLoopData = $crops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="t2">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($crop->product_name); ?></td>
                                <td><?php echo e($crop->crop_type); ?></td>
                                <td><?php echo e($crop->product_quantity); ?></td>
                                <td><?php echo e($crop->product_price); ?></td>
                                <td><?php echo e($crop->product_description); ?></td>
                                <td><?php echo e($crop->long_description); ?></td>
                                <td><?php echo e(asset($crop->product_image)); ?></td>
                                <td>
                                    <a href="" class="btn-success">Edit</a>
                                    <a href="<?php echo e(route('delete_crop',['id'=>$crop->id])); ?>" class="btn-success ">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>