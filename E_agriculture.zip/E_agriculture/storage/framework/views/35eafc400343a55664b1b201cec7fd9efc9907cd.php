<?php $__env->startSection('body'); ?>
    <h1 class="text-danger col-md-offset-4 "><?php echo e(Session::get('message')); ?></h1>

    <?php $__currentLoopData = $allCrops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allCrop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3 product-men">
            <div class="men-pro-item simpleCart_shelfItem">
                <div class="men-thumb-item">
                    <img  src="<?php echo e(asset($allCrop->product_image)); ?> " width="1000" height="400" >
                    <span class="product-new-top">New</span>
                </div>
                <div class="item-info-product ">
                    <h4 style="color: limegreen"><?php echo e($allCrop->product_name); ?></h4>
                    <div class="info-product-price">
                        <span class="item_price"><?php echo e($allCrop->product_quantity); ?></span>
                    </div>
                    <a href="<?php echo e(route('crop_details',['id'=>$allCrop->id])); ?>" class="item_add single-item hvr-outline-out button2">Details</a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>