<?php $__env->startSection('body'); ?>
    <link href="<?php echo e(asset('/')); ?>/css/manage.css" rel="stylesheet" type="text/css">

    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="m">Manage Crops Info</h3>
                    <h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
                    <table class="table table-bordered small text-center table-hover">
                        <tr class="t1">
                            <th>Sl No</th>
                            <th>product_name </th>
                            <th>crop_type </th>
                            <th>product_quantity</th>
                            <th>product_price</th>
                            <th>product_description</th>
                            <th>long_description</th>
                            <th>product_image</th>
                            <th>Action</th>
                        </tr>
                        <?php ($i=1); ?>;
                        <?php $__currentLoopData = $crops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="t2">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($crop->product_name); ?></td>
                                <td><?php echo e($crop->crop_type); ?></td>
                                <td><?php echo e($crop->product_quantity); ?></td>
                                <td><?php echo e($crop->product_price); ?></td>
                                <td><?php echo e($crop->product_description); ?></td>
                                <td><?php echo e($crop->long_description); ?></td>
                                <td><?php echo e(asset($crop->product_image)); ?></td>
                                <td>
                                    <a href="<?php echo e(route('edit_fruit',['id'=>$crop->id])); ?>" class="btn-success">Edit</a>
                                    <a href="<?php echo e(route('delete_fruit',['id'=>$crop->id])); ?>" class="btn-success ">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('farmer.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>