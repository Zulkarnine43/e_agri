<?php $__env->startSection('body'); ?>
    <div class="col-md-3 product-men">
        <div class="men-pro-item simpleCart_shelfItem">
            <div class="men-thumb-item">
                <img  src="<?php echo e(asset($crop->product_image)); ?> " width="1000" height="400" >
                <span class="product-new-top">New</span>
            </div>
            <div class="item-info-product ">
                <h4><a href=""><?php echo e($crop->product_name); ?></a></h4>
                <div class="info-product-price">
                    <span class="item_price"><?php echo e($crop->product_quantity); ?></span>
                </div>
                <a href="<?php echo e(route('crop_details',['id'=>$crop->id])); ?>" class="item_add single-item hvr-outline-out button2">Details</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>