<?php $__env->startSection('body'); ?>
    <link href="<?php echo e(asset('/')); ?>/css/manage.css" rel="stylesheet" type="text/css">

    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="m">Manage Customers Info</h3>
                    <h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
                    <table class="table table-bordered table-active small text-center table-hover">
                        <tr class="t1">
                            <th>Sl No</th>
                            <th>fullname</th>
                            <th>email </th>
                            <th>mobile </th>
                            <th>district</th>
                        </tr>
                        <?php ($i=1); ?>;
                        <?php $__currentLoopData = $cust_infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cust_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="t2">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($cust_info->fullname); ?></td>
                                <td><?php echo e($cust_info->email); ?></td>
                                <td><?php echo e($cust_info->mobile); ?></td>
                                <td><?php echo e($cust_info->district); ?></td>
                                <td></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('farmer.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>