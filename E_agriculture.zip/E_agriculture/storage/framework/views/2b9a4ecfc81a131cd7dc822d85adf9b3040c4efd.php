<?php $__env->startSection('body'); ?>

    <section class="news py-5" id="about">
        <div class="container py-lg-5">
            <div class="w3l_head">
                <h3 class="heading text-center" style="background-color: limegreen">Gallary</h3>
            </div>
            <div class="row news-grids py-lg-5 py-3 mt-3 text-center">
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 newsgrid1">
                    <img src="<?php echo e(asset($image->product_image)); ?>" height="300" width="300" alt="news image" class="img-fluid">
                </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('home.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>