<?php $__env->startSection('body'); ?>

    <div >
        <h1  style="color: limegreen ;margin-left: 550px">Welcome YOUR pAGE......</h1>
        <P style="color: black ;margin-left: 550px; font-size: 30px;font-style: italic; font-weight: bold;line-height: 120px">You can buy crops ....with bidding....$ found Farmers details.....</P>
    </div>


    <?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>