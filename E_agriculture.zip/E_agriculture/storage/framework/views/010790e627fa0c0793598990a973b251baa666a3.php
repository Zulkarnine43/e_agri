<?php $__env->startSection('body'); ?>


    <link href="<?php echo e(asset('/')); ?>/css/manage.css" rel="stylesheet" type="text/css">

    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="m">Manage Notification Info</h3>
                    <h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
                    <table class="table table-bordered small text-center">
                        <tr class="t1">
                            <th>Sl No</th>
                            <th>Crop_name </th>
                            <th>Name </th>
                            <th>Email</th>
                            <th>Mobile</th>
                            <th>Message</th>
                            <th>Creadted _at</th>
                            <th>Action</th>
                        </tr>
                        <?php ($i=1); ?>;
                        <?php $__currentLoopData = $crops; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="t2">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($crop->product_name); ?></td>
                                <td><?php echo e($crop->name); ?></td>
                                <td><?php echo e($crop->email); ?></td>
                                <td><?php echo e($crop->mobile); ?></td>
                                <td><?php echo e($crop->message); ?></td>
                                <td><?php echo e($crop->created_at); ?></td>
                                <td>
                                    <a href="" class="btn-success">Edit</a>
                                    <a href="" class="btn-success ">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('farmer.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>