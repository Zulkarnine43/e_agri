<?php $__env->startSection('body'); ?>

    <link href="<?php echo e(asset('/')); ?>/css/manage.css" rel="stylesheet" type="text/css">
    <div class="row">
        <div class="col-md-12">
            <div class="panel">
                <div class="panel-body">
                    <h3 class="m">Manage home Info</h3>
                    <table class="table table-bordered text-center table-hover" style="width: 90%">
                        <tr class="t1">
                            <th>Sl No</th>
                            <th>product_name</th>
                            <th>crop_type </th>
                            <th>product_quantity </th>
                            <th>product_price</th>
                            <th>product_description </th>
                            <th>long_description</th>
                            <th>product_image</th>
                            <th>Action</th>
                        </tr>
                        <?php ($i=1); ?>;
                        <?php $__currentLoopData = $home_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $home_pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="t2">
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($home_pro->product_name); ?></td>
                                <td><?php echo e($home_pro->crop_type); ?></td>
                                <td><?php echo e($home_pro->product_quantity); ?></td>
                                <td><?php echo e($home_pro->product_price); ?></td>
                                <td><?php echo e($home_pro->product_description); ?></td>
                                <td><?php echo e($home_pro->long_description); ?></td>
                                <td><?php echo e($home_pro->product_image); ?></td>
                                <td>
                                    <span><a href="">EDIT</a></span></br>
                                    <span><a href="<?php echo e(route('home_delete',['id'=>$home_pro->id])); ?>">DELETE</a></span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.headerFooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>